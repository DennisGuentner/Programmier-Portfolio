<?php

declare(strict_types=1);

namespace Team\Journaling\Tests\Unit\Domain\Model;

use PHPUnit\Framework\MockObject\MockObject;
use TYPO3\TestingFramework\Core\AccessibleObjectInterface;
use TYPO3\TestingFramework\Core\Unit\UnitTestCase;

/**
 * Test case
 */
class JournalingTest extends UnitTestCase
{
    /**
     * @var \Team\Journaling\Domain\Model\Journaling|MockObject|AccessibleObjectInterface
     */
    protected $subject;

    protected function setUp(): void
    {
        parent::setUp();

        $this->subject = $this->getAccessibleMock(
            \Team\Journaling\Domain\Model\Journaling::class,
            ['dummy']
        );
    }

    protected function tearDown(): void
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getTitelReturnsInitialValueForString(): void
    {
        self::assertSame(
            '',
            $this->subject->getTitel()
        );
    }

    /**
     * @test
     */
    public function setTitelForStringSetsTitel(): void
    {
        $this->subject->setTitel('Conceived at T3CON10');

        self::assertEquals('Conceived at T3CON10', $this->subject->_get('titel'));
    }

    /**
     * @test
     */
    public function getTextReturnsInitialValueForString(): void
    {
        self::assertSame(
            '',
            $this->subject->getText()
        );
    }

    /**
     * @test
     */
    public function setTextForStringSetsText(): void
    {
        $this->subject->setText('Conceived at T3CON10');

        self::assertEquals('Conceived at T3CON10', $this->subject->_get('text'));
    }

    /**
     * @test
     */
    public function getImageReturnsInitialValueForString(): void
    {
        self::assertSame(
            '',
            $this->subject->getImage()
        );
    }

    /**
     * @test
     */
    public function setImageForStringSetsImage(): void
    {
        $this->subject->setImage('Conceived at T3CON10');

        self::assertEquals('Conceived at T3CON10', $this->subject->_get('image'));
    }

    /**
     * @test
     */
    public function getEmotionReturnsInitialValueForString(): void
    {
        self::assertSame(
            '',
            $this->subject->getEmotion()
        );
    }

    /**
     * @test
     */
    public function setEmotionForStringSetsEmotion(): void
    {
        $this->subject->setEmotion('Conceived at T3CON10');

        self::assertEquals('Conceived at T3CON10', $this->subject->_get('emotion'));
    }

    /**
     * @test
     */
    public function getTagReturnsInitialValueForString(): void
    {
        self::assertSame(
            '',
            $this->subject->getTag()
        );
    }

    /**
     * @test
     */
    public function setTagForStringSetsTag(): void
    {
        $this->subject->setTag('Conceived at T3CON10');

        self::assertEquals('Conceived at T3CON10', $this->subject->_get('tag'));
    }

    /**
     * @test
     */
    public function getDateReturnsInitialValueForString(): void
    {
        self::assertSame(
            '',
            $this->subject->getDate()
        );
    }

    /**
     * @test
     */
    public function setDateForStringSetsDate(): void
    {
        $this->subject->setDate('Conceived at T3CON10');

        self::assertEquals('Conceived at T3CON10', $this->subject->_get('date'));
    }

    /**
     * @test
     */
    public function getTimeReturnsInitialValueForString(): void
    {
        self::assertSame(
            '',
            $this->subject->getTime()
        );
    }

    /**
     * @test
     */
    public function setTimeForStringSetsTime(): void
    {
        $this->subject->setTime('Conceived at T3CON10');

        self::assertEquals('Conceived at T3CON10', $this->subject->_get('time'));
    }
}
