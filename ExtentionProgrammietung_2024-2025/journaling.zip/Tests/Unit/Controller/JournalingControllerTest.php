<?php

declare(strict_types=1);

namespace Team\Journaling\Tests\Unit\Controller;

use PHPUnit\Framework\MockObject\MockObject;
use TYPO3\CMS\Extbase\Mvc\View\ViewInterface;
use TYPO3\TestingFramework\Core\AccessibleObjectInterface;
use TYPO3\TestingFramework\Core\Unit\UnitTestCase;

/**
 * Test case
 */
class JournalingControllerTest extends UnitTestCase
{
    /**
     * @var \Team\Journaling\Controller\JournalingController|MockObject|AccessibleObjectInterface
     */
    protected $subject;

    protected function setUp(): void
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder($this->buildAccessibleProxy(\Team\Journaling\Controller\JournalingController::class))
            ->onlyMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown(): void
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllJournalingsFromRepositoryAndAssignsThemToView(): void
    {
        $allJournalings = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $journalingRepository = $this->getMockBuilder(\Team\Journaling\Domain\Repository\JournalingRepository::class)
            ->onlyMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $journalingRepository->expects(self::once())->method('findAll')->will(self::returnValue($allJournalings));
        $this->subject->_set('journalingRepository', $journalingRepository);

        $view = $this->getMockBuilder(ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('journalings', $allJournalings);
        $this->subject->_set('view', $view);

        $this->subject->listAction();
    }

    /**
     * @test
     */
    public function showActionAssignsTheGivenJournalingToView(): void
    {
        $journaling = new \Team\Journaling\Domain\Model\Journaling();

        $view = $this->getMockBuilder(ViewInterface::class)->getMock();
        $this->subject->_set('view', $view);
        $view->expects(self::once())->method('assign')->with('journaling', $journaling);

        $this->subject->showAction($journaling);
    }

    /**
     * @test
     */
    public function createActionAddsTheGivenJournalingToJournalingRepository(): void
    {
        $journaling = new \Team\Journaling\Domain\Model\Journaling();

        $journalingRepository = $this->getMockBuilder(\Team\Journaling\Domain\Repository\JournalingRepository::class)
            ->onlyMethods(['add'])
            ->disableOriginalConstructor()
            ->getMock();

        $journalingRepository->expects(self::once())->method('add')->with($journaling);
        $this->subject->_set('journalingRepository', $journalingRepository);

        $this->subject->createAction($journaling);
    }

    /**
     * @test
     */
    public function editActionAssignsTheGivenJournalingToView(): void
    {
        $journaling = new \Team\Journaling\Domain\Model\Journaling();

        $view = $this->getMockBuilder(ViewInterface::class)->getMock();
        $this->subject->_set('view', $view);
        $view->expects(self::once())->method('assign')->with('journaling', $journaling);

        $this->subject->editAction($journaling);
    }

    /**
     * @test
     */
    public function updateActionUpdatesTheGivenJournalingInJournalingRepository(): void
    {
        $journaling = new \Team\Journaling\Domain\Model\Journaling();

        $journalingRepository = $this->getMockBuilder(\Team\Journaling\Domain\Repository\JournalingRepository::class)
            ->onlyMethods(['update'])
            ->disableOriginalConstructor()
            ->getMock();

        $journalingRepository->expects(self::once())->method('update')->with($journaling);
        $this->subject->_set('journalingRepository', $journalingRepository);

        $this->subject->updateAction($journaling);
    }

    /**
     * @test
     */
    public function deleteActionRemovesTheGivenJournalingFromJournalingRepository(): void
    {
        $journaling = new \Team\Journaling\Domain\Model\Journaling();

        $journalingRepository = $this->getMockBuilder(\Team\Journaling\Domain\Repository\JournalingRepository::class)
            ->onlyMethods(['remove'])
            ->disableOriginalConstructor()
            ->getMock();

        $journalingRepository->expects(self::once())->method('remove')->with($journaling);
        $this->subject->_set('journalingRepository', $journalingRepository);

        $this->subject->deleteAction($journaling);
    }
}
