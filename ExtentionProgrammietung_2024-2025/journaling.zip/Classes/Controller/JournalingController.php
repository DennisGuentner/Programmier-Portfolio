<?php

declare(strict_types=1);

namespace Team\Journaling\Controller;


/**
 * This file is part of the "journaling" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * (c) 2024 
 */

/**
 * JournalingController
 */
class JournalingController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * journalingRepository
     *
     * @var \Team\Journaling\Domain\Repository\JournalingRepository
     */
    protected $journalingRepository = null;

    /**
     * @param \Team\Journaling\Domain\Repository\JournalingRepository $journalingRepository
     */
    public function injectJournalingRepository(\Team\Journaling\Domain\Repository\JournalingRepository $journalingRepository)
    {
        $this->journalingRepository = $journalingRepository;
    }

    /**
     * action list
     *
     * @return string|object|null|void
     */
    public function listAction()
    {
        $journalings = $this->journalingRepository->findAllDescending();

        //Für die Tags Anzeige
        $allTags = [];

         // Durch alle Journals iterieren
        foreach ($journalings as $journaling) {
            $tags = explode('#', $journaling->getTag());  // Spalten der Tags mit `explode`

            // Tags zum Array hinzufügen und Duplikate entfernen
            foreach ($tags as $tag) {
                if (!empty($tag) && !in_array($tag, $allTags)) {
                    $allTags[] = $tag;
                }
            }
        }

        //Für den Kalender
        $journalingsArray = [];
        $emotionSums = [];
        $emotionCounts = [];

        foreach ($journalings as $journaling) {
            $date = $journaling->getDate();
            $emotion = $journaling->getEmotion();

            if (!isset($emotionSums[$date])) {
                $emotionSums[$date] = 0;
                $emotionCounts[$date] = 0;
            }

            $emotionSums[$date] += $emotion;
            $emotionCounts[$date]++;
        }

        foreach ($emotionSums as $date => $sum) {
            $journalingsArray[] = [
                'date' => $date,
                'emotion' => (int) round($sum / $emotionCounts[$date]) // Durchschnitt runden und in int umwandeln
            ];
        }
    
        //Variablen werden an die Seite gesendet
        $this->view->assignMultiple([
            'journalings' => $journalings,
            'journalingsJson' => json_encode($journalingsArray),
            'allTags' => $allTags

        ]);
    }

    
    public function listWithTagsAction(array $tags = [])
    {
        $journalings = $this->journalingRepository->findAllDescending();
        
        //Für die Tags Anzeige
        $allTags = [];

        // Durch alle Journals iterieren
        foreach ($journalings as $journaling) {
            $tags = explode('#', $journaling->getTag());  // Spalten der Tags mit `explode`

            // Tags zum Array hinzufügen und Duplikate entfernen
            foreach ($tags as $tag) {
                if (!empty($tag) && !in_array($tag, $allTags)) {
                    $allTags[] = $tag;
                }
            }
        }
    

        $selectedTags = $this->request->getArgument('tags') ?? []; // Hier weden die Tags genommen, die vom Benutzer ausgewählt wurden

        
        if (!empty($selectedTags)) {
            // Finde alle Journaleinträge, die mit den ausgewählten Tags übereinstimmen
            $filteredJournalings = [];
            
            foreach ($journalings as $journaling) {
                $tags = explode('#', $journaling->getTag()); // Spalten der Tags mit `explode`
                
                // Wenn das Journal mindestens einen der ausgewählten Tags enthält
                if (array_intersect($tags, $selectedTags)) {
                    $filteredJournalings[] = $journaling;
                }
            }
        } else {
            // Wenn keine Tags ausgewählt sind, zeige einfach alle Einträge an
            $filteredJournalings = $journalings;
        }

        //Für den Kalender
        $journalingsArray = [];
        $emotionSums = [];
        $emotionCounts = [];

        foreach ($filteredJournalings as $journaling) {
            $date = $journaling->getDate();
            $emotion = $journaling->getEmotion();

            if (!isset($emotionSums[$date])) {
                $emotionSums[$date] = 0;
                $emotionCounts[$date] = 0;
            }

            $emotionSums[$date] += $emotion;
            $emotionCounts[$date]++;
        }

        foreach ($emotionSums as $date => $sum) {
            $journalingsArray[] = [
                'date' => $date,
                'emotion' => (int) round($sum / $emotionCounts[$date]) // Durchschnitt runden und in int umwandeln
            ];
        }
        
        $this->view->assignMultiple([
            'journalings' => $filteredJournalings,
            'journalingsJson' => json_encode($journalingsArray),
            'allTags' => $allTags,
            'selectedTags' => $selectedTags
        ]);
    }

    /**
     * action show
     *
     * @param \Team\Journaling\Domain\Model\Journaling $journaling
     * @return string|object|null|void
     */
    /*public function showAction(\Team\Journaling\Domain\Model\Journaling $journaling)
    {
        $this->view->assign('journaling', $journaling);
    } */

    /**
     * action new
     *
     * @return string|object|null|void
     */
    public function newAction()
    {
    }

    /**
     * action newIMG
     *
     * @return string|object|null|void
     */
    public function newIMGAction(string $imageName)
    {
        $this->view->assign('imageName', $imageName);
    }


    /**
     * action create
     *
     * @param \Team\Journaling\Domain\Model\Journaling $newJournaling
     * @return string|object|null|void
     */
    public function createAction(\Team\Journaling\Domain\Model\Journaling $newJournaling)
    {  
        //Datum und Zeit der Erstellung des Journals wird generiert
        $date = date('d.m.Y');
        //$date = date("02.02.2025"); //Ist ein Test
        $time = date('H:i');
        
        //Datum und Zeit der Erstellung werden in die Datei $newJournaling eingetragen
        $newJournaling->setDate($date);
        $newJournaling->setTime($time);
        
        /*//Bild wird gespeichert
        //$imageData = $newJournaling->request->getArgument('image');
        $imageData = $newJournaling->getImage();
        $imageField = $imageData['image'];

        if(is_String($imageData)) {
        echo("Ja ist ein String");}

           //$dump = \TYPO3\CMS\Extbase\Utility\DebuggerUtility::var_dump($imageField);
           // Dateiupload
           // Achtung: das Verzeichnis "/var/www/site/htdocs/uploads/pics" erstellen und dem user www-data die Schreibrechte geben!
    	$basicFileFunctions = $this->objectManager->get('TYPO3\CMS\Core\Utility\File\BasicFileUtility');
    	$newFile = $basicFileFunctions->getUniqueName($imageField['name'],\TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( 'uploads/pics' ));
    	if (\TYPO3\CMS\Core\Utility\GeneralUtility::upload_copy_move($imageField['tmp_name'], $newFile)) {
            $fileInfo = pathinfo($newFile);
        } */

        //Neuer Eintrag in die Datenbank + Weiterleitung zu list
        $this->addFlashMessage('The object was created. Please be aware that this action is publicly accessible unless you implement an access check. See https://docs.typo3.org/p/friendsoftypo3/extension-builder/master/en-us/User/Index.html', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->journalingRepository->add($newJournaling);
        $this->redirect('list');
    }

    /**
     * action edit
     *
     * @param \Team\Journaling\Domain\Model\Journaling $journaling
     * @TYPO3\CMS\Extbase\Annotation\IgnoreValidation("journaling")
     * @return string|object|null|void
     */
    public function editAction(\Team\Journaling\Domain\Model\Journaling $journaling)
    {
        $this->view->assign('journaling', $journaling);
    }

    public function editIMGAction(\Team\Journaling\Domain\Model\Journaling $journaling)
    {
        $this->view->assign('journaling', $journaling);
    }

    /**
     * action update
     *
     * @param \Team\Journaling\Domain\Model\Journaling $journaling
     * @return string|object|null|void
     */
    public function updateAction(\Team\Journaling\Domain\Model\Journaling $journaling)
    {
        $this->addFlashMessage('The object was updated. Please be aware that this action is publicly accessible unless you implement an access check. See https://docs.typo3.org/p/friendsoftypo3/extension-builder/master/en-us/User/Index.html', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->journalingRepository->update($journaling);
        $this->redirect('list');
    }

    /**
     * action delete
     *
     * @param \Team\Journaling\Domain\Model\Journaling $journaling
     * @return string|object|null|void
     */
    public function deleteAction(\Team\Journaling\Domain\Model\Journaling $journaling)
    {
        $this->addFlashMessage('The object was deleted. Please be aware that this action is publicly accessible unless you implement an access check. See https://docs.typo3.org/p/friendsoftypo3/extension-builder/master/en-us/User/Index.html', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->journalingRepository->remove($journaling);
        $this->redirect('list');
    }

    /**
     * action uploadausfuehren
     *
     * 
     * @return void
     */
    public function uploadausfuehrenAction()
    {
        $formData = $this->request->getArgument('upload');
           $imageField = $formData['bild'];
           //$dump = \TYPO3\CMS\Extbase\Utility\DebuggerUtility::var_dump($imageField);
           // Dateiupload
           // Achtung: das Verzeichnis "/var/www/site/htdocs/uploads/pics" erstellen und dem user www-data die Schreibrechte geben!
    	$basicFileFunctions = $this->objectManager->get('TYPO3\CMS\Core\Utility\File\BasicFileUtility');
    	$newFile = $basicFileFunctions->getUniqueName($imageField['name'],\TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( 'uploads/pics' ));

        if (\TYPO3\CMS\Core\Utility\GeneralUtility::upload_copy_move($imageField['tmp_name'], $newFile)) {
            $fileInfo = pathinfo($newFile);
            $imageName = $fileInfo['basename']; // Speichert nur den Dateinamen, nicht den Pfad
        } else {
            $imageName = null; // Falls der Upload fehlschlägt
        }

        

        echo("Test");
        //$this->redirect('list');
        $this->redirect('newIMG', null, null, ['imageName' => $imageName]); //<-- Funktioniert nicht!
    }
}
