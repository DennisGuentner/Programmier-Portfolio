<?php

declare(strict_types=1);

namespace Team\Journaling\Domain\Model;


/**
 * This file is part of the "journaling" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * (c) 2024 
 */

/**
 * Journaling
 */
class Journaling extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * titel
     *
     * @var string
     */
    protected $titel = '';

    /**
     * text
     *
     * @var string
     */
    protected $text = '';

    /**
     * image
     *
     * @var string
     */
    protected $image = '';

    /**
     * emotion
     *
     * @var string
     */
    protected $emotion = '';

    /**
     * tag
     *
     * @var string
     */
    protected $tag = '';

    /**
     * date
     *
     * @var string
     */
    protected $date = '';

    /**
     * time
     *
     * @var string
     */
    protected $time = '';

    /**
     * Returns the titel
     *
     * @return string
     */
    public function getTitel()
    {
        return $this->titel;
    }

    /**
     * Sets the titel
     *
     * @param string $titel
     * @return void
     */
    public function setTitel(string $titel)
    {
        $this->titel = $titel;
    }

    /**
     * Returns the text
     *
     * @return string
     */
    public function getText()
    {
        return $this->text;
    }

    /**
     * Sets the text
     *
     * @param string $text
     * @return void
     */
    public function setText(string $text)
    {
        $this->text = $text;
    }

    /**
     * Returns the image
     *
     * @return string
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Sets the image
     *
     * @param string $image
     * @return void
     */
    public function setImage(string $image)
    {
        $this->image = $image;
    }

    /**
     * Returns the emotion
     *
     * @return string
     */
    public function getEmotion()
    {
        return $this->emotion;
    }

    /**
     * Sets the emotion
     *
     * @param string $emotion
     * @return void
     */
    public function setEmotion(string $emotion)
    {
        $this->emotion = $emotion;
    }

    /**
     * Returns the tag
     *
     * @return string
     */
    public function getTag()
    {
        return $this->tag;
    }

    /**
     * Sets the tag
     *
     * @param string $tag
     * @return void
     */
    public function setTag(string $tag)
    {
        $this->tag = $tag;
    }

    /**
     * Returns the date
     *
     * @return string
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Sets the date
     *
     * @param string $date
     * @return void
     */
    public function setDate(string $date)
    {
        $this->date = $date;
    }

    /**
     * Returns the time
     *
     * @return string
     */
    public function getTime()
    {
        return $this->time;
    }

    /**
     * Sets the time
     *
     * @param string $time
     * @return void
     */
    public function setTime(string $time)
    {
        $this->time = $time;
    }
}
