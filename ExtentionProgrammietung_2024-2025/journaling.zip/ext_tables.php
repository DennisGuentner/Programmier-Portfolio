<?php
defined('TYPO3_MODE') || die();

(static function() {
    \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerModule(
        'Journaling',
        'web',
        'journaling',
        '',
        [
            \Team\Journaling\Controller\JournalingController::class => 'list, show, new, create, edit, update, delete, newIMG, listWithTags',
        ],
        [
            'access' => 'user,group',
            'icon'   => 'EXT:journaling/Resources/Public/Icons/user_mod_journaling.svg',
            'labels' => 'LLL:EXT:journaling/Resources/Private/Language/locallang_journaling.xlf',
        ]
    );

    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_journaling_domain_model_journaling', 'EXT:journaling/Resources/Private/Language/locallang_csh_tx_journaling_domain_model_journaling.xlf');
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_journaling_domain_model_journaling');
})();
