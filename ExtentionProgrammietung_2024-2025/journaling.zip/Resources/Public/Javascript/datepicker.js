jQuery(document).ready(function () {
    console.log("Datepicker.js loaded!");
    if (jQuery("#datepicker").length) {
        jQuery("#datepicker").datepicker({
            inline: true,
            dateFormat: "dd.mm.yy",
            beforeShowDay: colorDate,
            onSelect: scrollToFirstEntry
        });
    }

    function colorDate(date) {
        var formattedDate = date.toLocaleDateString("de-DE",
            { day: "2-digit", month: "2-digit", year: "numeric" });

        for (var i = 0; i < data.length; i++) {
            if (data[i].date === formattedDate) {
                var emotionClass = "emotion-" + data[i].emotion;
                return [true, emotionClass, "Eintrag vorhanden"];
            }
        }
        return [true, "", ""];
    }

    function scrollToFirstEntry(date) {
        var firstElement = jQuery("h4").filter(function () {
            return jQuery(this).text().trim() === date;
        });
        if (firstElement.length) {
            jQuery('html, body').animate({
                scrollTop: firstElement.offset().top
            }, 500);
        }
    }
});