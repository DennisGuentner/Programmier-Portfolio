CREATE TABLE tx_journaling_domain_model_journaling (
	titel varchar(255) NOT NULL DEFAULT '',
	text text NOT NULL DEFAULT '',
	image varchar(255) NOT NULL DEFAULT '',
	emotion varchar(255) NOT NULL DEFAULT '',
	tag varchar(255) NOT NULL DEFAULT '',
	date varchar(255) NOT NULL DEFAULT '',
	time varchar(255) NOT NULL DEFAULT ''
);
