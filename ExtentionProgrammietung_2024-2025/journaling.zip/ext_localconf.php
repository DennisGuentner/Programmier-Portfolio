<?php
defined('TYPO3_MODE') || die();

(static function() {
    \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
        'Journaling',
        'Journaling',
        [
            \Team\Journaling\Controller\JournalingController::class => 'list, show, new, create, edit, update, delete, uploadausfuehren, newIMG, listWithTags'
        ],
        // non-cacheable actions
        [
            \Team\Journaling\Controller\JournalingController::class => 'create, update, delete, uploadausfuehren, listWithTags'
        ]
    );

    // wizards
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
        'mod {
            wizards.newContentElement.wizardItems.plugins {
                elements {
                    journaling {
                        iconIdentifier = journaling-plugin-journaling
                        title = LLL:EXT:journaling/Resources/Private/Language/locallang_db.xlf:tx_journaling_journaling.name
                        description = LLL:EXT:journaling/Resources/Private/Language/locallang_db.xlf:tx_journaling_journaling.description
                        tt_content_defValues {
                            CType = list
                            list_type = journaling_journaling
                        }
                    }
                }
                show = *
            }
       }'
    );

    $iconRegistry = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Imaging\IconRegistry::class);
    $iconRegistry->registerIcon(
        'journaling-plugin-journaling',
        \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
        ['source' => 'EXT:journaling/Resources/Public/Icons/user_plugin_journaling.svg']
    );
})();
